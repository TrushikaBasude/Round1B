# Document Intelligence System - Adobe Hackathon Round 1B

A CPU-optimized document intelligence system that extracts and ranks relevant sections from PDF collections based on user personas and specific job requirements.

## Overview

This system processes 3-10 related PDFs and intelligently extracts the most relevant sections based on:
- **Persona Definition**: Role description with expertise and focus areas
- **Job-to-be-Done**: Concrete task the persona needs to accomplish

The solution uses a hybrid approach combining rule-based text analysis with lightweight ML techniques, optimized for CPU-only execution within strict memory and time constraints.

## Key Features

- **Generalized Approach**: Works across diverse domains (research papers, textbooks, financial reports, etc.)
- **CPU Optimized**: No GPU dependencies, efficient memory usage
- **Fast Processing**: Completes processing in under 60 seconds for 3-5 documents
- **Offline Operation**: No internet access required during execution
- **Lightweight Models**: Total model size under 1GB

## Architecture

### Core Components

1. **Document Processor** (`document_processor.py`)
   - Extracts text and metadata from PDFs using pdfplumber
   - Analyzes font characteristics for structure detection
   - Optimized for memory efficiency

2. **Section Extractor** (`section_extractor.py`)
   - Identifies document sections using rule-based pattern matching
   - Extracts subsections with content refinement
   - Uses font analysis and text patterns for accurate detection

3. **Persona Matcher** (`persona_matcher.py`)
   - Matches sections to persona requirements using keyword analysis
   - Implements TF-IDF-like scoring for relevance calculation
   - Domain-agnostic approach with configurable keyword sets

4. **Ranking Engine** (`ranking_engine.py`)
   - Ranks sections using comprehensive scoring algorithm
   - Combines multiple factors: content quality, topic relevance, position, job alignment
   - Optimized for CPU execution with efficient similarity calculations

## Technical Approach

### Hybrid Scoring System
- **Rule-based matching**: Fast keyword and pattern matching
- **Statistical analysis**: TF-IDF scoring for term importance
- **Content quality metrics**: Length, structure, information density
- **Position weighting**: Section hierarchy and document position

### Memory Optimization
- Streaming PDF processing to minimize memory footprint
- Efficient text processing with configurable chunk sizes
- No large pre-trained models loaded into memory
- Garbage collection optimization for long document processing

### CPU Optimization
- Pure Python implementation with NumPy vectorization
- Batch processing for efficiency
- Minimal regex operations with compiled patterns
- Efficient data structures (sets, dictionaries) for fast lookups

## Input Format

The system expects a `config.json` file in `/app/input` with the following structure:

```json
{
  "documents": ["doc1.pdf", "doc2.pdf", "doc3.pdf"],
  "persona": {
    "role": "PhD Researcher",
    "expertise": ["Computational Biology", "Machine Learning"],
    "focus_areas": ["Drug Discovery", "Graph Neural Networks"]
  },
  "job_to_be_done": "Prepare a comprehensive literature review focusing on methodologies, datasets, and performance benchmarks"
}
