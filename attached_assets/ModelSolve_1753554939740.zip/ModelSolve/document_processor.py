"""
Document processor for extracting text and metadata from PDF files.
Optimized for CPU-only execution with efficient memory usage.
"""

import logging
import re
from pathlib import Path
from typing import Dict, List, Any, Tuple
import pdfplumber
from dataclasses import dataclass

@dataclass
class DocumentPage:
    """Represents a single page from a document."""
    page_num: int
    text: str
    font_sizes: List[float]
    font_names: List[str]
    bbox: Tuple[float, float, float, float]

@dataclass
class DocumentData:
    """Represents processed document data."""
    filename: str
    title: str
    pages: List[DocumentPage]
    total_pages: int
    metadata: Dict[str, Any]

class DocumentProcessor:
    """Processes PDF documents to extract structured text and metadata."""
    
    def __init__(self, config):
        self.config = config
        self.logger = logging.getLogger(__name__)
        
    def process_document(self, file_path: Path) -> DocumentData:
        """Process a single PDF document and extract structured data."""
        
        self.logger.info(f"Processing document: {file_path.name}")
        
        try:
            with pdfplumber.open(file_path) as pdf:
                # Extract metadata
                metadata = pdf.metadata or {}
                
                # Extract title from metadata or filename
                title = self._extract_title(metadata, file_path.name)
                
                # Process each page
                pages = []
                for page_num, page in enumerate(pdf.pages, 1):
                    page_data = self._process_page(page, page_num)
                    if page_data:
                        pages.append(page_data)
                
                doc_data = DocumentData(
                    filename=file_path.name,
                    title=title,
                    pages=pages,
                    total_pages=len(pages),
                    metadata=metadata
                )
                
                self.logger.info(f"Processed {len(pages)} pages from {file_path.name}")
                return doc_data
                
        except Exception as e:
            self.logger.error(f"Error processing document {file_path.name}: {str(e)}")
            raise
    
    def _extract_title(self, metadata: Dict[str, Any], filename: str) -> str:
        """Extract document title from metadata or filename."""
        
        # Try to get title from metadata
        title = metadata.get('Title') or metadata.get('title')
        
        if title and isinstance(title, str) and len(title.strip()) > 0:
            return title.strip()
        
        # Fallback to filename without extension
        return Path(filename).stem.replace('_', ' ').replace('-', ' ').title()
    
    def _process_page(self, page, page_num: int) -> DocumentPage | None:
        """Process a single page and extract text with formatting information."""
        
        try:
            # Extract text
            text = page.extract_text()
            if not text:
                return None
            
            # Clean text
            text = self._clean_text(text)
            
            # Extract character-level information for font analysis
            chars = page.chars
            font_sizes = []
            font_names = []
            
            for char in chars:
                if char.get('size'):
                    font_sizes.append(float(char['size']))
                if char.get('fontname'):
                    font_names.append(char['fontname'])
            
            # Get page bounding box
            bbox = page.bbox
            
            return DocumentPage(
                page_num=page_num,
                text=text,
                font_sizes=font_sizes,
                font_names=font_names,
                bbox=bbox
            )
            
        except Exception as e:
            self.logger.warning(f"Error processing page {page_num}: {str(e)}")
            return None
    
    def _clean_text(self, text: str) -> str:
        """Clean and normalize extracted text."""
        
        if not text:
            return ""
        
        # Remove excessive whitespace
        text = re.sub(r'\s+', ' ', text)
        
        # Remove page headers/footers (simple heuristic)
        lines = text.split('\n')
        cleaned_lines = []
        
        for line in lines:
            line = line.strip()
            
            # Skip very short lines that might be headers/footers
            if len(line) < 3:
                continue
                
            # Skip lines that are mostly numbers (page numbers, etc.)
            if re.match(r'^\d+\s*$', line):
                continue
                
            cleaned_lines.append(line)
        
        return '\n'.join(cleaned_lines).strip()
