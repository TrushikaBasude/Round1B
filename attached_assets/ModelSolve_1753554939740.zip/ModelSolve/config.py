"""
Configuration settings for the document intelligence system.
Optimized for CPU execution and memory efficiency.
"""

class Config:
    """Configuration class with system parameters."""
    
    def __init__(self):
        # Section extraction parameters
        self.MIN_SECTION_LENGTH = 50  # Minimum characters for a valid section
        self.MIN_SECTION_CONFIDENCE = 0.2  # Minimum confidence for section detection
        self.MIN_SUBSECTION_LENGTH = 30  # Minimum characters for subsection
        
        # Matching parameters
        self.MIN_MATCH_SCORE = 0.05  # Minimum score for section matching
        
        # Output limits
        self.MAX_SECTIONS = 20  # Maximum sections to include in output
        self.MAX_SUBSECTIONS_PER_SECTION = 3  # Maximum subsections per section
        self.MAX_TOTAL_SUBSECTIONS = 30  # Maximum total subsections
        
        # Processing parameters
        self.MAX_PROCESSING_TIME = 60  # Maximum processing time in seconds
        self.MEMORY_LIMIT_MB = 512  # Memory limit in MB
        
        # Text processing parameters
        self.MAX_TEXT_LENGTH = 10000  # Maximum text length to process per section
        self.CHUNK_SIZE = 1000  # Text chunk size for processing
        
        # Font analysis parameters
        self.FONT_SIZE_THRESHOLD = 2.0  # Minimum font size difference for headers
        self.HEADER_LENGTH_THRESHOLD = 100  # Maximum length for header detection
        
        # Scoring weights
        self.PERSONA_WEIGHT = 0.3
        self.EXPERTISE_WEIGHT = 0.25
        self.FOCUS_AREA_WEIGHT = 0.25
        self.JOB_KEYWORD_WEIGHT = 0.2
        
        # Performance optimization
        self.ENABLE_PARALLEL_PROCESSING = False  # Disabled for CPU optimization
        self.BATCH_SIZE = 5  # Number of sections to process in batch
        
        # Model parameters
        self.USE_SENTENCE_TRANSFORMERS = False  # Disabled to save memory
        self.USE_SPACY_MODEL = False  # Disabled to save memory and time
        
        # Debug settings
        self.DEBUG_MODE = False
        self.VERBOSE_LOGGING = True
