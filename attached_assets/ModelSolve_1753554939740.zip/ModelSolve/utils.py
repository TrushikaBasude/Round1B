"""
Utility functions for the document intelligence system.
"""

import logging
import json
import os
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Any

def setup_logging():
    """Setup logging configuration."""
    
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
        handlers=[
            logging.StreamHandler(),
        ]
    )

def validate_inputs(config: Dict[str, Any], input_dir: Path) -> None:
    """Validate input configuration and files."""
    
    # Check required fields
    required_fields = ["documents", "persona", "job_to_be_done"]
    for field in required_fields:
        if field not in config:
            raise ValueError(f"Missing required field: {field}")
    
    # Validate documents
    documents = config["documents"]
    if not isinstance(documents, list) or not documents:
        raise ValueError("Documents must be a non-empty list")
    
    # Check if document files exist
    for doc_name in documents:
        doc_path = input_dir / doc_name
        if not doc_path.exists():
            raise FileNotFoundError(f"Document not found: {doc_name}")
    
    # Validate persona
    persona = config["persona"]
    if not isinstance(persona, dict):
        raise ValueError("Persona must be a dictionary")
    
    if "role" not in persona:
        raise ValueError("Persona must have a 'role' field")
    
    # Validate job_to_be_done
    job_to_be_done = config["job_to_be_done"]
    if not isinstance(job_to_be_done, str) or not job_to_be_done.strip():
        raise ValueError("Job to be done must be a non-empty string")

def format_output(documents: List[str], persona: Dict[str, Any], 
                 job_to_be_done: str, sections: List[Any], 
                 subsections: List[Any], processing_time: float) -> Dict[str, Any]:
    """Format the output according to the required JSON structure."""
    
    # Format metadata
    metadata = {
        "input_documents": documents,
        "persona": persona,
        "job_to_be_done": job_to_be_done,
        "processing_timestamp": datetime.now().isoformat(),
        "processing_time_seconds": round(processing_time, 2),
        "total_sections_extracted": len(sections),
        "total_subsections_analyzed": len(subsections)
    }
    
    # Format extracted sections
    extracted_sections = []
    for section in sections:
        section_data = {
            "document": section.document,
            "page_number": section.page_number,
            "section_title": section.title,
            "importance_rank": getattr(section, 'importance_rank', 0),
            "relevance_score": round(getattr(section, 'relevance_score', 0.0), 3),
            "content_preview": section.content[:200] + "..." if len(section.content) > 200 else section.content
        }
        extracted_sections.append(section_data)
    
    # Format subsection analysis
    subsection_analysis = []
    for subsection in subsections:
        subsection_data = {
            "document": subsection.document,
            "section_title": subsection.section_title,
            "refined_text": subsection.refined_text,
            "page_number": subsection.page_number,
            "confidence": round(subsection.confidence, 3)
        }
        subsection_analysis.append(subsection_data)
    
    # Combine all data
    output_data = {
        "metadata": metadata,
        "extracted_sections": extracted_sections,
        "subsection_analysis": subsection_analysis
    }
    
    return output_data

def ensure_directory_exists(directory: Path) -> None:
    """Ensure a directory exists, create if it doesn't."""
    directory.mkdir(parents=True, exist_ok=True)

def safe_file_read(file_path: Path, encoding: str = 'utf-8') -> str:
    """Safely read a file with error handling."""
    try:
        with open(file_path, 'r', encoding=encoding) as f:
            return f.read()
    except UnicodeDecodeError:
        # Try with different encoding
        try:
            with open(file_path, 'r', encoding='latin-1') as f:
                return f.read()
        except Exception as e:
            raise RuntimeError(f"Failed to read file {file_path}: {str(e)}")
    except Exception as e:
        raise RuntimeError(f"Failed to read file {file_path}: {str(e)}")

def safe_json_write(data: Dict[str, Any], file_path: Path) -> None:
    """Safely write JSON data to file."""
    try:
        with open(file_path, 'w', encoding='utf-8') as f:
            json.dump(data, f, indent=2, ensure_ascii=False)
    except Exception as e:
        raise RuntimeError(f"Failed to write JSON to {file_path}: {str(e)}")
