"""
Persona matcher for matching document sections to user personas and job requirements.
Uses lightweight NLP models optimized for CPU execution.
"""

import logging
import re
from typing import Dict, List, Any, Tuple
from collections import defaultdict
import math

from section_extractor import Section

class PersonaMatcher:
    """Matches document sections to persona requirements using hybrid approach."""
    
    def __init__(self, config):
        self.config = config
        self.logger = logging.getLogger(__name__)
        
        # Domain-specific keywords for different personas
        self.persona_keywords = {
            "researcher": ["research", "study", "analysis", "methodology", "results", "findings", 
                          "literature", "hypothesis", "experiment", "data", "statistical", "significance",
                          "document", "pdf", "intelligence", "processing", "extraction", "artificial",
                          "machine", "learning", "algorithm", "model", "hackathon", "challenge"],
            "student": ["learn", "understand", "concept", "definition", "example", "practice",
                       "fundamental", "basic", "introduction", "overview", "summary", "key",
                       "tutorial", "guide", "instruction", "requirement", "constraint"],
            "analyst": ["trend", "performance", "metric", "benchmark", "comparison", "analysis",
                       "insight", "pattern", "correlation", "forecast", "evaluation", "assessment",
                       "report", "document", "scoring", "criteria", "constraint"],
            "manager": ["strategy", "planning", "decision", "implementation", "management", "leadership",
                       "objective", "goal", "resource", "budget", "timeline", "risk",
                       "requirement", "deliverable", "submission", "checklist"],
            "engineer": ["technical", "implementation", "architecture", "design", "system", "solution",
                        "specification", "requirement", "algorithm", "optimization", "performance",
                        "docker", "cpu", "memory", "processing", "execution", "code"],
            "consultant": ["recommendation", "solution", "strategy", "best practice", "framework",
                          "approach", "methodology", "assessment", "evaluation", "improvement",
                          "requirement", "constraint", "criteria", "scoring"]
        }
        
        # Job-specific keywords
        self.job_keywords = {
            "review": ["review", "survey", "overview", "comparison", "analysis", "evaluation"],
            "summary": ["summary", "conclusion", "key points", "main", "important", "essential"],
            "analysis": ["analysis", "examine", "investigate", "assess", "evaluate", "study"],
            "preparation": ["prepare", "study", "learn", "understand", "practice", "exam"],
            "research": ["research", "investigate", "explore", "discover", "find", "identify"],
            "implementation": ["implement", "deploy", "execute", "apply", "use", "practical"]
        }
    
    def match_sections(self, sections: List[Section], persona: Dict[str, Any], 
                      job_to_be_done: str) -> List[Tuple[Section, float]]:
        """Match sections to persona and job requirements."""
        
        self.logger.info(f"Matching {len(sections)} sections to persona requirements")
        
        # Extract persona characteristics
        role = persona.get("role", "").lower()
        expertise = persona.get("expertise", [])
        focus_areas = persona.get("focus_areas", [])
        
        # Process job requirements
        job_keywords = self._extract_job_keywords(job_to_be_done)
        
        matched_sections = []
        
        for section in sections:
            # Calculate matching score
            score = self._calculate_match_score(
                section, role, expertise, focus_areas, job_keywords
            )
            
            if score > self.config.MIN_MATCH_SCORE:
                matched_sections.append((section, score))
        
        # Sort by score (descending)
        matched_sections.sort(key=lambda x: x[1], reverse=True)
        
        self.logger.info(f"Matched {len(matched_sections)} sections above threshold")
        return matched_sections
    
    def _extract_job_keywords(self, job_description: str) -> List[str]:
        """Extract relevant keywords from job description."""
        
        job_lower = job_description.lower()
        keywords = set()
        
        # Extract keywords based on job type
        for job_type, type_keywords in self.job_keywords.items():
            if job_type in job_lower:
                keywords.update(type_keywords)
        
        # Extract domain-specific terms
        words = re.findall(r'\b\w+\b', job_lower)
        for word in words:
            if len(word) > 3:  # Filter out short words
                keywords.add(word)
        
        return list(keywords)
    
    def _calculate_match_score(self, section: Section, role: str, expertise: List[str],
                              focus_areas: List[str], job_keywords: List[str]) -> float:
        """Calculate matching score for a section."""
        
        content_lower = (section.title + " " + section.content).lower()
        score = 0.0
        
        # 1. Persona role matching (weight: 0.3)
        role_score = self._calculate_keyword_score(content_lower, self.persona_keywords.get(role, []))
        score += role_score * 0.3
        
        # 2. Expertise matching (weight: 0.25)
        expertise_score = 0.0
        if expertise:
            for exp in expertise:
                exp_keywords = exp.lower().split()
                exp_score = self._calculate_keyword_score(content_lower, exp_keywords)
                expertise_score = max(expertise_score, exp_score)
        score += expertise_score * 0.25
        
        # 3. Focus areas matching (weight: 0.25)
        focus_score = 0.0
        if focus_areas:
            for area in focus_areas:
                area_keywords = area.lower().split()
                area_score = self._calculate_keyword_score(content_lower, area_keywords)
                focus_score = max(focus_score, area_score)
        score += focus_score * 0.25
        
        # 4. Job keywords matching (weight: 0.2)
        job_score = self._calculate_keyword_score(content_lower, job_keywords)
        score += job_score * 0.2
        
        # Bonus for section characteristics
        # Longer sections get slight boost (more information)
        length_bonus = min(0.1, len(section.content) / 5000)
        score += length_bonus
        
        # Higher confidence sections get boost
        score += section.confidence * 0.05
        
        return min(1.0, score)  # Cap at 1.0
    
    def _calculate_keyword_score(self, content: str, keywords: List[str]) -> float:
        """Calculate keyword matching score using TF-IDF-like approach."""
        
        if not keywords:
            return 0.0
        
        content_words = re.findall(r'\b\w+\b', content.lower())
        content_length = len(content_words)
        
        if content_length == 0:
            return 0.0
        
        # Calculate term frequency for each keyword
        keyword_scores = []
        for keyword in keywords:
            # Count occurrences (including partial matches for compound terms)
            count = content.count(keyword.lower())
            
            # Add partial credit for word stems
            keyword_stem = keyword[:4] if len(keyword) > 4 else keyword
            stem_count = sum(1 for word in content_words if word.startswith(keyword_stem))
            count += stem_count * 0.5
            
            if count > 0:
                # TF score
                tf = count / content_length
                
                # Simple IDF approximation (keywords are considered important)
                idf = math.log(100 / (count + 1))  # Assume corpus size of 100
                
                tf_idf = tf * idf
                keyword_scores.append(tf_idf)
        
        # Return average score of matched keywords
        return sum(keyword_scores) / len(keywords) if keyword_scores else 0.0
