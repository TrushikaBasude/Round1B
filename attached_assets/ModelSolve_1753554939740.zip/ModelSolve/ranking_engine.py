"""
Ranking engine for ranking sections and subsections by relevance.
Uses efficient similarity calculations optimized for CPU execution.
"""

import logging
import math
from typing import Dict, List, Any, Tuple
from collections import Counter
import re

from section_extractor import Section, Subsection

class RankingEngine:
    """Ranks sections and subsections by relevance using multiple scoring factors."""
    
    def __init__(self, config):
        self.config = config
        self.logger = logging.getLogger(__name__)
        
    def rank_sections(self, matched_sections: List[Tuple[Section, float]], 
                     persona: Dict[str, Any], job_to_be_done: str) -> List[Section]:
        """Rank matched sections by comprehensive relevance score."""
        
        self.logger.info(f"Ranking {len(matched_sections)} matched sections")
        
        # Extract job context for additional scoring
        job_context = self._extract_job_context(job_to_be_done)
        
        # Calculate comprehensive scores
        scored_sections = []
        for section, match_score in matched_sections:
            comprehensive_score = self._calculate_comprehensive_score(
                section, match_score, persona, job_context
            )
            scored_sections.append((section, comprehensive_score))
        
        # Sort by comprehensive score
        scored_sections.sort(key=lambda x: x[1], reverse=True)
        
        # Extract sections and add importance rank
        ranked_sections = []
        for i, (section, score) in enumerate(scored_sections):
            # Add importance rank as attribute for output formatting
            section.importance_rank = i + 1
            section.relevance_score = score
            ranked_sections.append(section)
        
        if scored_sections:
            self.logger.info(f"Ranked sections with scores ranging from {scored_sections[0][1]:.3f} to {scored_sections[-1][1]:.3f}")
        else:
            self.logger.info("No sections to rank")
        return ranked_sections
    
    def rank_subsections(self, subsections: List[Subsection], 
                        persona: Dict[str, Any], job_to_be_done: str) -> List[Subsection]:
        """Rank subsections by relevance."""
        
        job_context = self._extract_job_context(job_to_be_done)
        
        scored_subsections = []
        for subsection in subsections:
            score = self._calculate_subsection_score(subsection, persona, job_context)
            scored_subsections.append((subsection, score))
        
        # Sort by score
        scored_subsections.sort(key=lambda x: x[1], reverse=True)
        
        # Extract subsections
        ranked_subsections = [subsection for subsection, _ in scored_subsections]
        
        return ranked_subsections
    
    def _extract_job_context(self, job_description: str) -> Dict[str, Any]:
        """Extract context and intent from job description."""
        
        job_lower = job_description.lower()
        
        # Identify job type/intent
        job_type = "general"
        if any(word in job_lower for word in ["review", "survey", "overview"]):
            job_type = "review"
        elif any(word in job_lower for word in ["summary", "summarize", "conclude"]):
            job_type = "summary"
        elif any(word in job_lower for word in ["analyze", "analysis", "examine"]):
            job_type = "analysis"
        elif any(word in job_lower for word in ["learn", "study", "understand", "prepare"]):
            job_type = "learning"
        elif any(word in job_lower for word in ["implement", "apply", "use", "practical"]):
            job_type = "implementation"
        
        # Extract key topics/domains
        topics = re.findall(r'\b[A-Z][a-z]+(?:\s[A-Z][a-z]+)*\b', job_description)
        topics.extend(re.findall(r'\b\w{4,}\b', job_lower))
        
        # Filter and deduplicate topics
        topics = list(set([topic.lower() for topic in topics if len(topic) > 3]))
        
        return {
            "type": job_type,
            "topics": topics,
            "length": len(job_description),
            "specificity": len(topics) / max(1, len(job_description.split()))
        }
    
    def _calculate_comprehensive_score(self, section: Section, match_score: float,
                                     persona: Dict[str, Any], job_context: Dict[str, Any]) -> float:
        """Calculate comprehensive relevance score for a section."""
        
        content = section.title + " " + section.content
        content_lower = content.lower()
        
        # Start with base match score (weight: 0.4)
        score = match_score * 0.4
        
        # Content quality score (weight: 0.2)
        quality_score = self._calculate_content_quality(section)
        score += quality_score * 0.2
        
        # Topic relevance score (weight: 0.2)
        topic_score = self._calculate_topic_relevance(content_lower, job_context["topics"])
        score += topic_score * 0.2
        
        # Position/structure score (weight: 0.1)
        position_score = self._calculate_position_score(section)
        score += position_score * 0.1
        
        # Job type alignment score (weight: 0.1)
        job_alignment_score = self._calculate_job_alignment(content_lower, job_context["type"])
        score += job_alignment_score * 0.1
        
        return min(1.0, score)
    
    def _calculate_subsection_score(self, subsection: Subsection, 
                                  persona: Dict[str, Any], job_context: Dict[str, Any]) -> float:
        """Calculate relevance score for a subsection."""
        
        content_lower = subsection.refined_text.lower()
        
        # Topic relevance (weight: 0.4)
        topic_score = self._calculate_topic_relevance(content_lower, job_context["topics"])
        score = topic_score * 0.4
        
        # Content density (weight: 0.3)
        density_score = self._calculate_content_density(subsection.refined_text)
        score += density_score * 0.3
        
        # Job alignment (weight: 0.2)
        job_score = self._calculate_job_alignment(content_lower, job_context["type"])
        score += job_score * 0.2
        
        # Base confidence (weight: 0.1)
        score += subsection.confidence * 0.1
        
        return min(1.0, score)
    
    def _calculate_content_quality(self, section: Section) -> float:
        """Calculate content quality score based on various factors."""
        
        content = section.content
        if not content:
            return 0.0
        
        quality_score = 0.0
        
        # Length factor (optimal range)
        length = len(content)
        if 200 <= length <= 2000:
            quality_score += 0.3
        elif 100 <= length < 200 or 2000 < length <= 5000:
            quality_score += 0.2
        elif length > 50:
            quality_score += 0.1
        
        # Sentence structure
        sentences = re.split(r'[.!?]+', content)
        avg_sentence_length = sum(len(s.split()) for s in sentences) / max(1, len(sentences))
        if 10 <= avg_sentence_length <= 25:
            quality_score += 0.2
        
        # Information density (presence of specific terms)
        info_indicators = ["data", "result", "analysis", "study", "research", "finding", 
                          "method", "approach", "technique", "theory", "concept"]
        info_count = sum(1 for indicator in info_indicators if indicator in content.lower())
        quality_score += min(0.2, info_count * 0.05)
        
        # Structure indicators
        structure_indicators = ["first", "second", "furthermore", "however", "therefore", 
                              "in conclusion", "specifically", "for example"]
        structure_count = sum(1 for indicator in structure_indicators if indicator in content.lower())
        quality_score += min(0.3, structure_count * 0.1)
        
        return min(1.0, quality_score)
    
    def _calculate_topic_relevance(self, content: str, topics: List[str]) -> float:
        """Calculate relevance to job topics."""
        
        if not topics:
            return 0.5  # Neutral score if no topics
        
        relevance_scores = []
        for topic in topics:
            # Direct match
            if topic in content:
                relevance_scores.append(1.0)
            else:
                # Partial match using word overlap
                topic_words = set(topic.split())
                content_words = set(re.findall(r'\b\w+\b', content))
                overlap = len(topic_words.intersection(content_words))
                if overlap > 0:
                    relevance_scores.append(overlap / len(topic_words))
        
        return sum(relevance_scores) / len(topics) if relevance_scores else 0.0
    
    def _calculate_position_score(self, section: Section) -> float:
        """Calculate score based on section position and characteristics."""
        
        position_score = 0.0
        
        # Level-based scoring (H1 > H2 > H3)
        if section.level == "H1":
            position_score += 0.4
        elif section.level == "H2":
            position_score += 0.3
        elif section.level == "H3":
            position_score += 0.2
        
        # Early pages get slight boost (intro/important content)
        if section.page_number <= 3:
            position_score += 0.3
        elif section.page_number <= 10:
            position_score += 0.2
        
        # Section confidence
        position_score += section.confidence * 0.3
        
        return min(1.0, position_score)
    
    def _calculate_job_alignment(self, content: str, job_type: str) -> float:
        """Calculate alignment with job type requirements."""
        
        job_type_indicators = {
            "review": ["review", "overview", "survey", "comparison", "literature", "studies"],
            "summary": ["summary", "conclusion", "key", "main", "important", "essential"],
            "analysis": ["analysis", "analyze", "examine", "investigate", "evaluate", "assess"],
            "learning": ["learn", "understand", "concept", "definition", "basic", "fundamental"],
            "implementation": ["implement", "apply", "practical", "use", "method", "technique"],
            "general": ["information", "data", "content", "text", "section", "part"]
        }
        
        indicators = job_type_indicators.get(job_type, job_type_indicators["general"])
        
        alignment_score = 0.0
        for indicator in indicators:
            if indicator in content:
                alignment_score += 1.0 / len(indicators)
        
        return min(1.0, alignment_score)
    
    def _calculate_content_density(self, content: str) -> float:
        """Calculate information density of content."""
        
        if not content:
            return 0.0
        
        words = re.findall(r'\b\w+\b', content.lower())
        if not words:
            return 0.0
        
        # Count meaningful words (length > 3)
        meaningful_words = [word for word in words if len(word) > 3]
        
        # Calculate unique word ratio
        unique_ratio = len(set(meaningful_words)) / len(meaningful_words) if meaningful_words else 0
        
        # Calculate average word length
        avg_word_length = sum(len(word) for word in meaningful_words) / len(meaningful_words) if meaningful_words else 0
        
        # Combine factors
        density = (unique_ratio * 0.6) + (min(1.0, avg_word_length / 8) * 0.4)
        
        return density
