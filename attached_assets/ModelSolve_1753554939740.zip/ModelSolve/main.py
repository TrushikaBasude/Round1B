#!/usr/bin/env python3
"""
Adobe Hackathon Round 1B - Document Intelligence System
Main entry point for processing PDF collections based on persona and job requirements.
"""

import json
import os
import sys
import time
import logging
from pathlib import Path
from typing import Dict, List, Any

from document_processor import DocumentProcessor
from section_extractor import SectionExtractor
from persona_matcher import PersonaMatcher
from ranking_engine import RankingEngine
from utils import setup_logging, validate_inputs, format_output
from config import Config

def main():
    """Main execution function for the document intelligence system."""
    
    # Setup logging
    setup_logging()
    logger = logging.getLogger(__name__)
    
    try:
        # Initialize configuration
        config = Config()
        
        # Define input and output paths
        input_dir = Path("./input")
        output_dir = Path("./output")
        
        # Ensure output directory exists
        output_dir.mkdir(parents=True, exist_ok=True)
        
        # Read input configuration
        config_file = input_dir / "config.json"
        if not config_file.exists():
            raise FileNotFoundError(f"Configuration file not found: {config_file}")
        
        with open(config_file, 'r', encoding='utf-8') as f:
            input_config = json.load(f)
        
        # Validate inputs
        validate_inputs(input_config, input_dir)
        
        # Extract configuration
        documents = input_config.get("documents", [])
        persona = input_config.get("persona", {})
        job_to_be_done = input_config.get("job_to_be_done", "")
        
        logger.info(f"Processing {len(documents)} documents for persona: {persona.get('role', 'Unknown')}")
        
        # Start processing timer
        start_time = time.time()
        
        # Initialize components
        doc_processor = DocumentProcessor(config)
        section_extractor = SectionExtractor(config)
        persona_matcher = PersonaMatcher(config)
        ranking_engine = RankingEngine(config)
        
        # Process all documents
        processed_documents = []
        for doc_name in documents:
            doc_path = input_dir / doc_name
            if doc_path.exists():
                logger.info(f"Processing document: {doc_name}")
                doc_data = doc_processor.process_document(doc_path)
                processed_documents.append(doc_data)
            else:
                logger.warning(f"Document not found: {doc_name}")
        
        if not processed_documents:
            raise ValueError("No valid documents found to process")
        
        # Extract sections from all documents
        logger.info("Extracting sections from documents...")
        all_sections = []
        for doc_data in processed_documents:
            sections = section_extractor.extract_sections(doc_data)
            all_sections.extend(sections)
        
        logger.info(f"Extracted {len(all_sections)} sections total")
        
        # If no sections found, create basic content blocks from the text
        if not all_sections:
            logger.info("No structured sections found, creating content blocks from pages...")
            all_sections = section_extractor.create_fallback_sections(processed_documents)
            logger.info(f"Created {len(all_sections)} fallback content blocks")
        
        # Match sections to persona and job requirements
        logger.info("Matching sections to persona requirements...")
        matched_sections = persona_matcher.match_sections(all_sections, persona, job_to_be_done)
        
        # Rank sections by relevance
        logger.info("Ranking sections by relevance...")
        ranked_sections = ranking_engine.rank_sections(matched_sections, persona, job_to_be_done)
        
        # Generate sub-section analysis for top sections
        logger.info("Generating sub-section analysis...")
        top_sections = ranked_sections[:config.MAX_SECTIONS]
        subsection_analysis = []
        
        for section in top_sections:
            subsections = section_extractor.extract_subsections(section)
            ranked_subsections = ranking_engine.rank_subsections(subsections, persona, job_to_be_done)
            subsection_analysis.extend(ranked_subsections[:config.MAX_SUBSECTIONS_PER_SECTION])
        
        # Format output
        processing_time = time.time() - start_time
        logger.info(f"Processing completed in {processing_time:.2f} seconds")
        
        output_data = format_output(
            documents=documents,
            persona=persona,
            job_to_be_done=job_to_be_done,
            sections=ranked_sections,
            subsections=subsection_analysis,
            processing_time=processing_time
        )
        
        # Write output
        output_file = output_dir / "result.json"
        with open(output_file, 'w', encoding='utf-8') as f:
            json.dump(output_data, f, indent=2, ensure_ascii=False)
        
        logger.info(f"Results written to: {output_file}")
        logger.info(f"Total processing time: {processing_time:.2f} seconds")
        
        return 0
        
    except Exception as e:
        logger.error(f"Processing failed: {str(e)}")
        return 1

if __name__ == "__main__":
    sys.exit(main())
