"""
Section extractor for identifying and extracting document sections and subsections.
Uses rule-based approaches combined with text analysis for CPU efficiency.
"""

import logging
import re
from typing import Dict, List, Any, Tuple
from dataclasses import dataclass
from collections import Counter
import statistics

from document_processor import DocumentData, DocumentPage

@dataclass
class Section:
    """Represents a document section."""
    document: str
    title: str
    content: str
    page_number: int
    level: str  # H1, H2, H3, etc.
    start_pos: int
    end_pos: int
    font_size: float
    confidence: float

@dataclass
class Subsection:
    """Represents a document subsection."""
    document: str
    section_title: str
    content: str
    refined_text: str
    page_number: int
    confidence: float

class SectionExtractor:
    """Extracts sections and subsections from processed documents."""
    
    def __init__(self, config):
        self.config = config
        self.logger = logging.getLogger(__name__)
        
        # Patterns for identifying section headers
        self.section_patterns = [
            # Common section headers (exact matches)
            r'^(Abstract|Introduction|Methodology|Results|Discussion|Conclusion|References)$',
            r'^(Executive Summary|Overview|Background|Analysis|Findings|Recommendations)$',
            r'^(Your Mission|Why This Matters|What You Need to Build|Docker Requirements|Expected Execution|Constraints|Scoring Criteria|Submission Checklist|Pro Tips|What Not to Do)$',
            r'^(Challenge Brief|Input Specification|Sample Test Cases|Required Output|Deliverables|Appendix)$',
            r'^(The Journey Ahead|Round \d+[AB]?:?.*?)$',
            r'^(Test Case \d+:.*?)$',
            
            # Numbered sections
            r'^(\d+\.?\s+.+?)$',
            r'^(\d+\.\d+\.?\s+.+?)$',
            r'^(\d+\.\d+\.\d+\.?\s+.+?)$',
            
            # Roman numerals
            r'^([IVX]+\.?\s+.+?)$',
            
            # Lettered sections
            r'^([A-Z]\.?\s+.+?)$',
            
            # Headers with colons
            r'^([A-Z][^:]+:?)$',
            
            # Challenge/Theme headers
            r'^(Challenge Theme:.*?)$',
            r'^(Theme:.*?)$',
        ]
        
    def extract_sections(self, doc_data: DocumentData) -> List[Section]:
        """Extract sections from a processed document."""
        
        self.logger.info(f"Extracting sections from {doc_data.filename}")
        sections = []
        
        # Analyze font sizes to identify headers
        font_analysis = self._analyze_fonts(doc_data)
        
        # Process each page
        for page in doc_data.pages:
            page_sections = self._extract_page_sections(
                page, doc_data.filename, font_analysis
            )
            sections.extend(page_sections)
        
        # Post-process sections to improve quality
        sections = self._post_process_sections(sections)
        
        self.logger.info(f"Extracted {len(sections)} sections from {doc_data.filename}")
        return sections
    
    def extract_subsections(self, section: Section) -> List[Subsection]:
        """Extract subsections from a section."""
        
        subsections = []
        content = section.content
        
        # Split content into paragraphs
        paragraphs = [p.strip() for p in content.split('\n\n') if p.strip()]
        
        for i, paragraph in enumerate(paragraphs):
            if len(paragraph) > self.config.MIN_SUBSECTION_LENGTH:
                # Refine text by removing redundant information
                refined_text = self._refine_text(paragraph)
                
                subsection = Subsection(
                    document=section.document,
                    section_title=section.title,
                    content=paragraph,
                    refined_text=refined_text,
                    page_number=section.page_number,
                    confidence=0.8  # Base confidence for subsections
                )
                subsections.append(subsection)
        
        return subsections
    
    def _analyze_fonts(self, doc_data: DocumentData) -> Dict[str, Any]:
        """Analyze font sizes and names to identify header patterns."""
        
        all_font_sizes = []
        all_font_names = []
        
        for page in doc_data.pages:
            all_font_sizes.extend(page.font_sizes)
            all_font_names.extend(page.font_names)
        
        if not all_font_sizes:
            return {"base_size": 12.0, "header_sizes": [14.0, 16.0, 18.0]}
        
        # Calculate statistics
        median_size = statistics.median(all_font_sizes)
        size_counter = Counter(all_font_sizes)
        common_sizes = [size for size, _ in size_counter.most_common(5)]
        
        # Identify likely header sizes (larger than median)
        header_sizes = [size for size in common_sizes if size > median_size]
        
        # Identify common font names
        font_counter = Counter(all_font_names)
        common_fonts = [font for font, _ in font_counter.most_common(3)]
        
        return {
            "base_size": median_size,
            "header_sizes": header_sizes,
            "common_fonts": common_fonts,
            "all_sizes": sorted(set(all_font_sizes), reverse=True)
        }
    
    def _extract_page_sections(self, page: DocumentPage, filename: str, 
                             font_analysis: Dict[str, Any]) -> List[Section]:
        """Extract sections from a single page."""
        
        sections = []
        text = page.text
        lines = text.split('\n')
        
        current_section = None
        current_content = []
        
        for i, line in enumerate(lines):
            line = line.strip()
            if not line:
                continue
            
            # Check if line is a potential section header
            is_header, level, confidence = self._is_section_header(
                line, i, lines, font_analysis
            )
            
            if is_header and confidence > self.config.MIN_SECTION_CONFIDENCE:
                # Save previous section
                if current_section and current_content:
                    current_section.content = '\n'.join(current_content).strip()
                    sections.append(current_section)
                
                # Start new section
                current_section = Section(
                    document=filename,
                    title=line,
                    content="",
                    page_number=page.page_num,
                    level=level,
                    start_pos=i,
                    end_pos=i,
                    font_size=self._estimate_font_size(line, font_analysis),
                    confidence=confidence
                )
                current_content = []
            
            elif current_section:
                # Add content to current section
                current_content.append(line)
                current_section.end_pos = i
        
        # Save final section
        if current_section and current_content:
            current_section.content = '\n'.join(current_content).strip()
            sections.append(current_section)
        
        return sections
    
    def _is_section_header(self, line: str, line_idx: int, all_lines: List[str], 
                          font_analysis: Dict[str, Any]) -> Tuple[bool, str, float]:
        """Determine if a line is a section header."""
        
        confidence = 0.0
        level = "H3"
        
        # Check against patterns
        for pattern in self.section_patterns:
            if re.match(pattern, line, re.IGNORECASE):
                confidence += 0.4
                break
        
        # Check line characteristics
        # Short lines are more likely to be headers
        if len(line) < 100:
            confidence += 0.2
        
        # Lines in title case are more likely to be headers
        if line.istitle() or line.isupper():
            confidence += 0.2
        
        # Check if followed by content
        if line_idx + 1 < len(all_lines) and all_lines[line_idx + 1].strip():
            confidence += 0.1
        
        # Determine level based on numbering or formatting
        if re.match(r'^\d+\.?\s+', line):
            level = "H1"
            confidence += 0.1
        elif re.match(r'^\d+\.\d+\.?\s+', line):
            level = "H2"
            confidence += 0.1
        elif re.match(r'^\d+\.\d+\.\d+\.?\s+', line):
            level = "H3"
            confidence += 0.1
        
        return confidence > 0.2, level, confidence
    
    def _estimate_font_size(self, line: str, font_analysis: Dict[str, Any]) -> float:
        """Estimate font size for a line (simplified heuristic)."""
        
        base_size = font_analysis.get("base_size", 12.0)
        header_sizes = font_analysis.get("header_sizes", [14.0])
        
        # Simple heuristic based on line characteristics
        if len(line) < 50 and (line.istitle() or line.isupper()):
            return max(header_sizes) if header_sizes else base_size + 2
        
        return base_size
    
    def _post_process_sections(self, sections: List[Section]) -> List[Section]:
        """Post-process sections to improve quality and remove noise."""
        
        # Filter out very short sections
        filtered_sections = []
        for section in sections:
            if len(section.content) >= self.config.MIN_SECTION_LENGTH:
                filtered_sections.append(section)
        
        # Sort by page number and position
        filtered_sections.sort(key=lambda s: (s.page_number, s.start_pos))
        
        return filtered_sections
    
    def create_fallback_sections(self, documents: List[DocumentData]) -> List[Section]:
        """Create fallback sections when no structured sections are found."""
        
        fallback_sections = []
        
        for doc_data in documents:
            for page in doc_data.pages:
                # Split page content into meaningful chunks
                content = page.text
                if len(content) < self.config.MIN_SECTION_LENGTH:
                    continue
                    
                # Look for paragraph breaks to create sections
                chunks = content.split('\n\n')
                chunk_content = []
                current_title = None
                
                for chunk in chunks:
                    chunk = chunk.strip()
                    if not chunk:
                        continue
                        
                    # Check if this chunk looks like a title/header
                    lines = chunk.split('\n')
                    first_line = lines[0].strip()
                    
                    # Simple heuristics for titles
                    is_potential_title = (
                        len(first_line) < 100 and
                        (first_line.isupper() or 
                         first_line.istitle() or
                         first_line.endswith(':') or
                         any(word in first_line.lower() for word in ['round', 'challenge', 'mission', 'requirements', 'constraints']))
                    )
                    
                    if is_potential_title and chunk_content:
                        # Create section from accumulated content
                        section = Section(
                            document=doc_data.filename,
                            title=current_title or f"Content Block {len(fallback_sections)+1}",
                            content='\n\n'.join(chunk_content),
                            page_number=page.page_num,
                            level="H2",
                            start_pos=0,
                            end_pos=len(chunk_content),
                            font_size=12.0,
                            confidence=0.5
                        )
                        fallback_sections.append(section)
                        chunk_content = []
                        current_title = first_line
                    
                    chunk_content.append(chunk)
                
                # Add final section if there's remaining content
                if chunk_content:
                    section = Section(
                        document=doc_data.filename,
                        title=current_title or f"Content Block {len(fallback_sections)+1}",
                        content='\n\n'.join(chunk_content),
                        page_number=page.page_num,
                        level="H2",
                        start_pos=0,
                        end_pos=len(chunk_content),
                        font_size=12.0,
                        confidence=0.5
                    )
                    fallback_sections.append(section)
        
        return fallback_sections
    
    def _refine_text(self, text: str) -> str:
        """Refine text by removing redundant information and improving readability."""
        
        # Remove excessive whitespace
        text = re.sub(r'\s+', ' ', text)
        
        # Remove common noise patterns
        text = re.sub(r'\b(page \d+|figure \d+|table \d+)\b', '', text, flags=re.IGNORECASE)
        
        # Ensure text ends properly
        if text and not text.endswith(('.', '!', '?', ':')):
            text += '.'
        
        return text.strip()
